import paho.mqtt.client as mqtt
from fastapi import FastAPI

from scripts.config.applications_config import mqtt_host, port, request_no
from scripts.core.engine.redis_db import conn
from scripts.core.handlers.reading_doctors import read_doctors

# This is the Subscriber

app = FastAPI()


# subscribing to the doctor topics and getting the messages
@app.get("/")
def receiver():
    # subscribe to the doctor topics
    def on_connect(client_name, userdata, flags, rc):
        print(userdata, " ", flags)
        print("Connected with result code " + str(rc))
        read_doctors(conn, client_name)

    # printing the messages
    def on_message(client_name, userdata, msg):
        print(client_name, " ", userdata)
        # decoding the msg to string
        payload_decoded = msg.payload.decode('utf-8')
        print(msg.topic, "assigned to", payload_decoded)

    # creating the paho client for mqtt
    client = mqtt.Client()
    client.connect(mqtt_host, int(port), int(request_no))
    client.on_connect = on_connect
    client.on_message = on_message
    client.loop_forever()
