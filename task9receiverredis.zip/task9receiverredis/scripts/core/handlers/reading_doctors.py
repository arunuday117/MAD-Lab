# get the doctor topics to subscribe
def read_doctors(conn, client_name):
    no_doctors = conn.get("Doctors")
    doctors_list = []
    for doctors in range(0, int(no_doctors)):
        tup_doctors = ('doctor' + str(doctors), 0)
        doctors_list.append(tup_doctors)
    client_name.subscribe(doctors_list)
