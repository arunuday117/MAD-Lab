# connecting to the redis
import redis

from scripts.config.applications_config import redis_host

conn = redis.Redis(redis_host)
