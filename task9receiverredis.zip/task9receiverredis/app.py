import uvicorn

from scripts.config.applications_config import uvicorn_host, uvicorn_port

# starting the application
if __name__ == "__main__":
    print("redis MQTT task")
    uvicorn.run("scripts.services.receiver_app_run:app", host=uvicorn_host, port=int(uvicorn_port))
